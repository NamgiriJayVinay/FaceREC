package com.example.privacyview.services;

import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

import com.example.privacyview.R;

public class PrivacyViewTileService extends TileService {
    private boolean isServiceRunning = false;


    @Override
    public void onClick() {
        Tile tile = getQsTile();


        if (isServiceRunning) {
            // Stop the foreground service
            stopService(new Intent(this, PrivacyViewForegroundService.class));
            isServiceRunning = false;
            tile.setState(Tile.STATE_INACTIVE); // Update tile state
            tile.setIcon(Icon.createWithResource(this, R.drawable.icon_disabled));

        } else {
            // Start the foreground service
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(new Intent(this, PrivacyViewForegroundService.class));
            }
            isServiceRunning = true;
            tile.setState(Tile.STATE_ACTIVE); // Update tile state
            tile.setIcon(Icon.createWithResource(this, R.drawable.icon_enabled));

        }

        tile.updateTile(); // Refresh the tile
    }

    @Override
    public void onStartListening() {
        // Sync tile state with service status
        Tile tile = getQsTile();
        if (isServiceRunning) {
            tile.setState(Tile.STATE_ACTIVE);
            tile.setIcon(Icon.createWithResource(this, R.drawable.icon_enabled));


        } else {
            tile.setState(Tile.STATE_INACTIVE);
            tile.setIcon(Icon.createWithResource(this, R.drawable.icon_disabled));

        }
        tile.updateTile();

    }

    @Override
    public void onStopListening() {
        // Handle when tile is removed or stopped
    }

    @Override
    public void onTileAdded() {
        Tile tile = getQsTile();
        tile.setState(Tile.STATE_INACTIVE); // Default state
        tile.setIcon(Icon.createWithResource(this, R.drawable.icon_disabled)); // Default icon
        tile.updateTile();
    }

}

