package com.example.privacyview.UI;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.StatusBarManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.example.privacyview.R;
import com.example.privacyview.services.PrivacyViewTileService;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.function.Consumer;


public class NavActivity extends AppCompatActivity {


    private static final int PERMISSION_REQUEST_CODE = 1001;
    private static final int REQUEST_OVERLAY_PERMISSION = 1002;

   Button register,recognise;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nav);

        register=findViewById(R.id.register_button);
        recognise=findViewById(R.id.recognizeButton);

        register.setOnClickListener((v)->redirectToRegistration());
        recognise.setOnClickListener((v)->redirectToRecognition());

        requestPermissions();
    }

    private void requestPermissions() {
        String[] permissions;

        // Check if the permission is granted
        if (!Settings.canDrawOverlays(this)) {
            // Permission is not granted, request it
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
        } else {
            // Permission is already granted, proceed with the intended functionality
            // ...
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions = new String[]{
                    android.Manifest.permission.CAMERA,
                    android.Manifest.permission.READ_MEDIA_IMAGES
            };
        } else {
            permissions = new String[]{
                    android.Manifest.permission.CAMERA,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
            };
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            addQuickSettingsTile(this);
        } else {
            // Handle cases for older Android versions (e.g., show a message to the user)
            Toast.makeText(this, "Quick Settings tile addition is not supported on your device.", Toast.LENGTH_SHORT).show();
        }





        if (!hasPermissions(permissions)) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }

    }

    private boolean hasPermissions(String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    @SuppressLint("WrongConstant")
    public void addQuickSettingsTile(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            StatusBarManager statusBarManager = (StatusBarManager) context.getSystemService("statusbar");

            if (statusBarManager != null) {
                ComponentName tileServiceComponentName = new ComponentName(context, PrivacyViewTileService.class);
                CharSequence tileLabel = "Privacy View";
                Icon tileIcon = Icon.createWithResource(context, R.drawable.icon_disabled);

                Executor executor = Executors.newSingleThreadExecutor();
                Consumer<Integer> resultCallback = result -> {
                    switch (result) {
                        case StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED:
                            System.out.println("Tile added successfully.");
                            break;
                        case StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED:
                            System.out.println("Tile is already added.");
                            break;
                        case StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_NOT_ADDED:
                            System.out.println("Tile could not be added.");
                            break;
                        default:
                            System.out.println("Unknown result: " + result);
                    }
                };

                statusBarManager.requestAddTileService(tileServiceComponentName, tileLabel, tileIcon, executor, resultCallback);
            } else {
                System.out.println("StatusBarManager is not available.");
            }
        } else {
            System.out.println("Quick Settings tile addition is not supported on devices below Android 13.");
        }
    }

    private void redirectToRecognition() {
        // Create an Intent to start the second Activity
        Intent intent = new Intent(this, MainActivity.class);
        // Start the second Activity
        startActivity(intent);
    }

    private void redirectToRegistration() {

        // Create an Intent to start the second Activity
        Intent intent = new Intent(this, MainActivity.class);

        // Add the string "register" as an extra to the Intent
        intent.putExtra("register", "true");

        // Start the second Activity
        startActivity(intent);
    }


}